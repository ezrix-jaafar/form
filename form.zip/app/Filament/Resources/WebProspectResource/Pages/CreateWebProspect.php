<?php

namespace App\Filament\Resources\WebProspectResource\Pages;

use App\Filament\Resources\WebProspectResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWebProspect extends CreateRecord
{
    protected static string $resource = WebProspectResource::class;
}
