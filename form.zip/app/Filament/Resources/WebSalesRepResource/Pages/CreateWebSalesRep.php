<?php

namespace App\Filament\Resources\WebSalesRepResource\Pages;

use App\Filament\Resources\WebSalesRepResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWebSalesRep extends CreateRecord
{
    protected static string $resource = WebSalesRepResource::class;
}
