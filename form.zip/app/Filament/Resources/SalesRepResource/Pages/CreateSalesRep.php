<?php

namespace App\Filament\Resources\SalesRepResource\Pages;

use App\Filament\Resources\SalesRepResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSalesRep extends CreateRecord
{
    protected static string $resource = SalesRepResource::class;
}
